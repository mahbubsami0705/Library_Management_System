# book_manager/return_book.py

from utils.file_manager import load_books, save_books

def return_book():
    isbn = input("Enter the ISBN of the book to return: ")
    books = load_books()
    for book in books:
        if book.isbn == isbn:
            if not book.is_borrowed:
                print(f"'{book.title}' was not borrowed.")
            else:
                book.is_borrowed = False
                save_books(books)
                print(f"Thank you for returning '{book.title}'.")
            return
    print("Book not found.")
