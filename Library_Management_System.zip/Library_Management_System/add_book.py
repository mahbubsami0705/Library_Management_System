# book_manager/add_book.py

from book_manager.book import Book
from utils.file_manager import load_books, save_books

def add_book():
    title = input("Enter the book title: ")
    authors_input = input("Enter the book authors (comma-separated): ")
    authors = [author.strip() for author in authors_input.split(',')]
    isbn = input("Enter the book ISBN: ")

    new_book = Book(title, authors, isbn)
    books = load_books()
    books.append(new_book)
    save_books(books)

    print(f"Added '{title}' by {', '.join(authors)}.")
