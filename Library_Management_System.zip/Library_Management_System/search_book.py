# book_manager/search_book.py

from utils.file_manager import load_books

def search_book():
    isbn = input("Enter the ISBN of the book to search for: ")
    books = load_books()
    for book in books:
        if book.isbn == isbn:
            print(book)
            return
    print("Book not found.")
