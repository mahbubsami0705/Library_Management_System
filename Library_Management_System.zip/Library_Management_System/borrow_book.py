# book_manager/borrow_book.py

from utils.file_manager import load_books, save_books

def borrow_book():
    isbn = input("Enter the ISBN of the book to borrow: ")
    books = load_books()
    for book in books:
        if book.isbn == isbn:
            if book.is_borrowed:
                print(f"'{book.title}' is already borrowed.")
            else:
                book.is_borrowed = True
                save_books(books)
                print(f"You have borrowed '{book.title}'.")
            return
    print("Book not found.")
