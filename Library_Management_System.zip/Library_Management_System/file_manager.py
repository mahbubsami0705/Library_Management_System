# utils/file_manager.py

import os
import pickle
from book_manager.book import Book

BOOKS_FILE = 'books.pkl'

def load_books():
    if not os.path.exists(BOOKS_FILE):
        return []
    with open(BOOKS_FILE, 'rb') as file:
        return pickle.load(file)

def save_books(books):
    with open(BOOKS_FILE, 'wb') as file:
        pickle.dump(books, file)
